#!/usr/bin/env python
# coding: utf-8

# In[11]:


import requests
from bs4 import BeautifulSoup
import lxml
import pandas as pd


# In[2]:


url = "https://www.contextures.com/xlSampleData01.html"
response = requests.get(url)
response.status_code


# In[5]:


soup = BeautifulSoup(response.text,'lxml')
print(soup)


# In[7]:


sales_table = soup.find('table')
print(sales_table.text)


# In[10]:


table_rows = sales_table.find_all('tr')
print(table_rows)


# In[16]:


extract_contents = lambda row: [x.text.replace('\n', '') for x in row] 
info = []
for tr in table_rows:
    row_all = extract_contents(tr.find_all('td'))
    info.append(row_all)
df1 = pd.DataFrame(info)
df1
    
    
    


# In[18]:


df1.to_excel('Sales_data1.xlsx')


# In[ ]:




